"""
config.py
---------
Centralised configuration for the YOLO + OpenCV Unique-Object Video
Counter project.

Keeping every tunable value in one dataclass makes the rest of the
codebase easy to maintain (Maintainability - NFR) and lets the same
code run on different videos / models without touching the logic
(Scalability - NFR) simply by passing different CLI flags into
`from_args`.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class AppConfig:
    """All runtime settings for a single processing run."""

    # --- Input / output -------------------------------------------------
    input_path: str                       # path to the input video file (or 0 for webcam)
    output_video_path: str = "output/annotated_output.mp4"
    output_report_path: str = "output/count_report.json"
    output_csv_path: str = "output/count_report.csv"

    # --- Model ------------------------------------------------------------
    model_path: str = "yolov8n.pt"        # ultralytics model weights
    confidence_threshold: float = 0.40
    nms_iou_threshold: float = 0.45
    device: str = "cpu"                   # "cpu" or "cuda:0"

    # --- Classes of interest ----------------------------------------------
    # Empty list => track every class the model can detect.
    classes_of_interest: List[str] = field(default_factory=list)

    # --- Tracking / unique-counting ---------------------------------------
    tracker_max_disappeared: int = 15     # frames a track may vanish before being dropped
    tracker_iou_threshold: float = 0.30   # min IoU to associate a detection with a track

    # --- Performance --------------------------------------------------------
    frame_resize_width: Optional[int] = 960   # None => keep native resolution
    process_every_nth_frame: int = 1          # >1 skips frames for speed

    # --- Logging -------------------------------------------------------------
    log_level: str = "INFO"
    log_file: str = "output/run.log"

    @staticmethod
    def from_args(args) -> "AppConfig":
        """Build an AppConfig from an argparse.Namespace."""
        return AppConfig(
            input_path=args.input,
            output_video_path=args.output,
            output_report_path=args.report,
            output_csv_path=args.csv,
            model_path=args.model,
            confidence_threshold=args.conf,
            device=args.device,
            classes_of_interest=args.classes.split(",") if args.classes else [],
            tracker_max_disappeared=args.max_disappeared,
            tracker_iou_threshold=args.iou,
            frame_resize_width=args.resize_width,
            process_every_nth_frame=args.skip,
            log_level=args.log_level,
        )
