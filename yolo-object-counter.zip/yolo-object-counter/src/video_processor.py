"""
video_processor.py
-------------------
Orchestrates the full pipeline: read frame -> detect -> track ->
count -> annotate -> write. This is the "workflow" referenced in the
design documentation (see docs/workflow_diagram.png).
"""

import time
from logging import Logger

from src.config import AppConfig
from src.counter import ObjectCounter
from src.detector import YoloDetector
from src.tracker import CentroidIOUTracker
from src.video_io import VideoReader, VideoWriter
from src.visualizer import draw_annotations, save_csv_report, save_json_report


class VideoProcessor:
    def __init__(self, config: AppConfig, logger: Logger):
        self.config = config
        self.logger = logger

        self.detector = YoloDetector(
            model_path=config.model_path,
            confidence_threshold=config.confidence_threshold,
            iou_threshold=config.nms_iou_threshold,
            device=config.device,
            classes_of_interest=config.classes_of_interest,
        )
        self.tracker = CentroidIOUTracker(
            max_disappeared=config.tracker_max_disappeared,
            iou_threshold=config.tracker_iou_threshold,
        )
        self.counter = ObjectCounter()

    def run(self) -> dict:
        self.logger.info("Loading YOLO model from %s ...", self.config.model_path)
        self.detector.load()

        self.logger.info("Opening video source: %s", self.config.input_path)
        reader = VideoReader(self.config.input_path, resize_width=self.config.frame_resize_width)
        writer = VideoWriter(
            self.config.output_video_path,
            fps=reader.fps,
            frame_size=(reader.out_width, reader.out_height),
        )

        start_time = time.time()
        frames_processed = 0

        try:
            for frame_idx, frame in reader.frames():
                if frame_idx % self.config.process_every_nth_frame != 0:
                    continue

                try:
                    detections = self.detector.detect(frame)
                except Exception as exc:  # noqa: BLE001
                    self.logger.error("Detection failed on frame %d: %s", frame_idx, exc)
                    detections = []

                tracks = self.tracker.update(detections)
                live_counts = self.counter.update(tracks)
                annotated = draw_annotations(frame, tracks, live_counts, self.counter.summary())
                writer.write(annotated)

                frames_processed += 1
                if frames_processed % 50 == 0:
                    self.logger.info("Processed %d frames...", frames_processed)

        finally:
            reader.release()
            writer.release()

        elapsed = time.time() - start_time
        summary = self.counter.summary()

        save_json_report(self.config.output_report_path, summary, frames_processed, reader.fps)
        save_csv_report(self.config.output_csv_path, summary)

        self.logger.info(
            "Done. %d frames processed in %.1fs (%.1f FPS). Unique objects found: %s",
            frames_processed, elapsed, frames_processed / elapsed if elapsed > 0 else 0.0, summary,
        )

        return {
            "frames_processed": frames_processed,
            "elapsed_seconds": elapsed,
            "unique_counts": summary,
            "total_unique_objects": self.counter.total_unique_objects(),
        }
