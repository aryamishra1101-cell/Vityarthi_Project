"""
tracker.py
----------
Functional Module 2: Tracking & Unique-Instance Assignment

This is the piece that makes the project different from a plain
"run YOLO on every frame" script. YOLO alone has no memory between
frames, so if the same dog is visible for 90 frames a naive counter
would report "dog: 90". This module assigns a persistent track ID to
each physical object (using centroid distance + IoU matching, in the
spirit of a simplified SORT tracker) so the counting module can
report "dog: 1" for that single animal, and a new ID only when a
genuinely new object enters the scene.

Design notes:
- No external tracking library is used, so the whole pipeline has a
  minimal, auditable dependency footprint (Reliability - NFR).
- The matching cost combines centroid distance and IoU, which keeps
  IDs stable for both fast- and slow-moving objects.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import numpy as np

from src.detector import Detection


def _iou(box_a: Tuple[float, float, float, float], box_b: Tuple[float, float, float, float]) -> float:
    """Intersection-over-Union of two (x1, y1, x2, y2) boxes."""
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b

    inter_x1, inter_y1 = max(ax1, bx1), max(ay1, by1)
    inter_x2, inter_y2 = min(ax2, bx2), min(ay2, by2)

    inter_w, inter_h = max(0.0, inter_x2 - inter_x1), max(0.0, inter_y2 - inter_y1)
    inter_area = inter_w * inter_h

    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter_area

    return inter_area / union if union > 0 else 0.0


@dataclass
class Track:
    """A single tracked object, persisted across frames."""

    track_id: int
    class_name: str
    box: Tuple[float, float, float, float]
    confidence: float
    frames_visible: int = 1
    frames_disappeared: int = 0


@dataclass
class CentroidIOUTracker:
    """
    Assigns stable IDs to detections across frames.

    max_disappeared: how many consecutive frames a track may go
        unmatched before it is considered gone (handles brief
        occlusion / missed detections).
    iou_threshold: minimum IoU for a detection to be linked to an
        existing track of the SAME class.
    """

    max_disappeared: int = 15
    iou_threshold: float = 0.3

    _next_id: int = field(default=0, init=False)
    tracks: Dict[int, Track] = field(default_factory=dict, init=False)

    def update(self, detections: List[Detection]) -> Dict[int, Track]:
        """Advance the tracker by one frame and return the active tracks."""

        if not self.tracks:
            for det in detections:
                self._register(det)
            return self.tracks

        if not detections:
            for track_id in list(self.tracks.keys()):
                self._mark_disappeared(track_id)
            return self.tracks

        unmatched_tracks = set(self.tracks.keys())
        unmatched_detections = set(range(len(detections)))

        # Build a cost table (negative IoU, only within the same class) and
        # greedily match the best pairs first - simple, fast, and easy to
        # reason about for a course project of this scope.
        candidate_pairs = []
        for track_id, track in self.tracks.items():
            for det_idx, det in enumerate(detections):
                if det.class_name != track.class_name:
                    continue
                score = _iou(track.box, det.box)
                if score >= self.iou_threshold:
                    candidate_pairs.append((score, track_id, det_idx))

        candidate_pairs.sort(key=lambda x: x[0], reverse=True)

        for score, track_id, det_idx in candidate_pairs:
            if track_id not in unmatched_tracks or det_idx not in unmatched_detections:
                continue
            det = detections[det_idx]
            track = self.tracks[track_id]
            track.box = det.box
            track.confidence = det.confidence
            track.frames_visible += 1
            track.frames_disappeared = 0
            unmatched_tracks.discard(track_id)
            unmatched_detections.discard(det_idx)

        for track_id in unmatched_tracks:
            self._mark_disappeared(track_id)

        for det_idx in unmatched_detections:
            self._register(detections[det_idx])

        return self.tracks

    def _register(self, detection: Detection) -> None:
        self.tracks[self._next_id] = Track(
            track_id=self._next_id,
            class_name=detection.class_name,
            box=detection.box,
            confidence=detection.confidence,
        )
        self._next_id += 1

    def _mark_disappeared(self, track_id: int) -> None:
        track = self.tracks[track_id]
        track.frames_disappeared += 1
        if track.frames_disappeared > self.max_disappeared:
            del self.tracks[track_id]
