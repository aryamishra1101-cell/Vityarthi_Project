"""
logger_utils.py
----------------
Small helper that configures a project-wide logger.

Having a single, consistently formatted logger satisfies the
"Logging / Monitoring" non-functional requirement and makes it far
easier to debug a run after the fact than scattering print()
statements through the code.
"""

import logging
import os
from logging.handlers import RotatingFileHandler


def get_logger(name: str, log_file: str = "output/run.log", level: str = "INFO") -> logging.Logger:
    """Return a configured logger that writes to console + a rotating file."""

    logger = logging.getLogger(name)
    if logger.handlers:
        # Already configured (avoids duplicate handlers on repeated calls).
        return logger

    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(fmt)
    logger.addHandler(console_handler)

    # File handler (rotates at 2MB, keeps 3 backups)
    try:
        os.makedirs(os.path.dirname(log_file) or ".", exist_ok=True)
        file_handler = RotatingFileHandler(log_file, maxBytes=2_000_000, backupCount=3)
        file_handler.setFormatter(fmt)
        logger.addHandler(file_handler)
    except OSError:
        # Fall back silently to console-only logging if the filesystem
        # is read-only or the path is invalid (Reliability - NFR).
        logger.warning("Could not create log file at %s - continuing with console logging only.", log_file)

    return logger
