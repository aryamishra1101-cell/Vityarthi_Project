"""
video_io.py
-----------
Small helpers around cv2.VideoCapture / cv2.VideoWriter so that
main.py and video_processor.py don't have to deal with fourcc codes,
frame resizing or malformed-file errors directly.
"""

import os
from typing import Optional, Tuple

import cv2
import numpy as np


class VideoReader:
    """Wraps cv2.VideoCapture with clearer errors and optional resizing."""

    def __init__(self, source, resize_width: Optional[int] = None):
        self.source = source
        self.resize_width = resize_width
        self.cap = cv2.VideoCapture(source)

        if not self.cap.isOpened():
            raise FileNotFoundError(
                f"Could not open video source '{source}'. Check the path or camera index."
            )

        self.fps = self.cap.get(cv2.CAP_PROP_FPS) or 25.0
        self.frame_count = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        if self.resize_width and self.width > 0:
            scale = self.resize_width / self.width
            self.out_width = self.resize_width
            self.out_height = int(self.height * scale)
        else:
            self.out_width, self.out_height = self.width, self.height

    def frames(self):
        """Generator yielding (frame_index, frame) tuples until the video ends."""
        idx = 0
        while True:
            ok, frame = self.cap.read()
            if not ok:
                break
            if self.resize_width:
                frame = cv2.resize(frame, (self.out_width, self.out_height))
            yield idx, frame
            idx += 1

    def release(self):
        self.cap.release()


class VideoWriter:
    """Wraps cv2.VideoWriter with a sensible default codec."""

    def __init__(self, path: str, fps: float, frame_size: Tuple[int, int]):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        self.writer = cv2.VideoWriter(path, fourcc, fps, frame_size)
        if not self.writer.isOpened():
            raise IOError(f"Could not open output video for writing at '{path}'.")

    def write(self, frame: np.ndarray) -> None:
        self.writer.write(frame)

    def release(self) -> None:
        self.writer.release()
