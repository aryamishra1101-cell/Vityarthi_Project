"""
Unit tests for src.tracker.CentroidIOUTracker

Run with:  python -m pytest tests/ -v
"""

import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.detector import Detection
from src.tracker import CentroidIOUTracker, _iou


def make_detection(class_name="person", box=(0, 0, 10, 10), conf=0.9):
    return Detection(class_id=0, class_name=class_name, confidence=conf, box=box)


def test_iou_identical_boxes_is_one():
    box = (0, 0, 10, 10)
    assert _iou(box, box) == 1.0


def test_iou_disjoint_boxes_is_zero():
    assert _iou((0, 0, 10, 10), (100, 100, 110, 110)) == 0.0


def test_new_detection_creates_new_track():
    tracker = CentroidIOUTracker()
    tracks = tracker.update([make_detection(box=(0, 0, 10, 10))])
    assert len(tracks) == 1


def test_same_object_moving_slightly_keeps_same_id():
    tracker = CentroidIOUTracker(iou_threshold=0.3)

    tracks = tracker.update([make_detection(box=(0, 0, 10, 10))])
    first_id = list(tracks.keys())[0]

    # Small shift - should still match via IoU and reuse the same ID.
    tracks = tracker.update([make_detection(box=(1, 1, 11, 11))])
    second_id = list(tracks.keys())[0]

    assert first_id == second_id
    assert len(tracker.tracks) == 1


def test_far_away_detection_of_same_class_gets_new_id():
    tracker = CentroidIOUTracker(iou_threshold=0.3)
    tracker.update([make_detection(box=(0, 0, 10, 10))])
    tracks = tracker.update([make_detection(box=(500, 500, 510, 510))])

    # The far-away box does not overlap the first one, and the first
    # track should now be marked as disappeared (not deleted yet).
    assert len(tracker.tracks) == 2


def test_track_is_dropped_after_max_disappeared_frames():
    tracker = CentroidIOUTracker(max_disappeared=2)
    tracker.update([make_detection(box=(0, 0, 10, 10))])

    tracker.update([])  # frame 2: missed
    tracker.update([])  # frame 3: missed
    tracker.update([])  # frame 4: missed - exceeds max_disappeared

    assert len(tracker.tracks) == 0


def test_different_classes_never_share_a_track():
    tracker = CentroidIOUTracker()
    tracks = tracker.update([
        make_detection(class_name="car", box=(0, 0, 10, 10)),
        make_detection(class_name="person", box=(0, 0, 10, 10)),
    ])
    assert len(tracks) == 2
