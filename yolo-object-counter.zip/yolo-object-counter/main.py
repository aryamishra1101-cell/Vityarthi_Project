#!/usr/bin/env python3
"""
main.py
-------
Command-line entry point.

Example:
    python main.py --input sample_media/input_sample.mp4 \\
                    --output output/annotated_output.mp4 \\
                    --model yolov8n.pt --conf 0.4

Run `python main.py --help` for the full list of options.

This script deliberately has NO GUI dependency - it can be run from
any terminal (local machine, remote server, or CI runner), which
satisfies the "fully executable via the command line" submission
requirement.
"""

import argparse
import sys

from src.config import AppConfig
from src.logger_utils import get_logger
from src.video_processor import VideoProcessor


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Detect, track and count unique objects appearing in a video using YOLO + OpenCV."
    )
    parser.add_argument("--input", "-i", required=True, help="Path to input video file, or 0 for webcam.")
    parser.add_argument("--output", "-o", default="output/annotated_output.mp4", help="Path for the annotated output video.")
    parser.add_argument("--report", default="output/count_report.json", help="Path for the JSON summary report.")
    parser.add_argument("--csv", default="output/count_report.csv", help="Path for the CSV summary report.")
    parser.add_argument("--model", "-m", default="yolov8n.pt", help="Path (or name) of the YOLO weights file.")
    parser.add_argument("--conf", type=float, default=0.40, help="Detection confidence threshold (0-1).")
    parser.add_argument("--iou", type=float, default=0.30, help="IoU threshold used by the tracker for ID matching.")
    parser.add_argument("--device", default="cpu", help="'cpu' or a CUDA device such as 'cuda:0'.")
    parser.add_argument("--classes", default="", help="Comma-separated list of class names to keep (default: all).")
    parser.add_argument("--max-disappeared", dest="max_disappeared", type=int, default=15,
                         help="Frames a track may go unmatched before being dropped.")
    parser.add_argument("--resize-width", dest="resize_width", type=int, default=960,
                         help="Resize frames to this width before processing (0 = keep original).")
    parser.add_argument("--skip", type=int, default=1, help="Process every Nth frame (1 = every frame).")
    parser.add_argument("--log-level", dest="log_level", default="INFO",
                         choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return parser


def main() -> int:
    args = build_arg_parser().parse_args()
    if args.resize_width == 0:
        args.resize_width = None

    config = AppConfig.from_args(args)
    logger = get_logger("yolo_counter", log_file=config.log_file, level=config.log_level)

    try:
        processor = VideoProcessor(config, logger)
        result = processor.run()
    except FileNotFoundError as exc:
        logger.error(str(exc))
        return 1
    except RuntimeError as exc:
        logger.error(str(exc))
        return 1
    except KeyboardInterrupt:
        logger.warning("Interrupted by user.")
        return 130

    logger.info("Summary: %s", result["unique_counts"])
    logger.info("Total unique objects detected: %d", result["total_unique_objects"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
