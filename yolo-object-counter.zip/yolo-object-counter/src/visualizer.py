"""
visualizer.py
-------------
Functional Module 3: Visualization & Reporting

Draws bounding boxes, track IDs and a live running-count panel onto
each frame, and exposes helpers to persist the final tally as JSON
and CSV so the results can be consumed by other tools (e.g. a
spreadsheet or a downstream dashboard).
"""

import csv
import json
import os
from typing import Dict

import cv2
import numpy as np

from src.tracker import Track

# A small, fixed palette keeps colours stable across a run instead of
# flickering randomly frame to frame.
_PALETTE = [
    (66, 135, 245), (52, 168, 83), (234, 67, 53), (251, 188, 5),
    (156, 39, 176), (0, 172, 193), (255, 112, 67), (141, 110, 99),
]


def _color_for(class_name: str) -> tuple:
    return _PALETTE[hash(class_name) % len(_PALETTE)]


def draw_annotations(frame: np.ndarray, tracks: Dict[int, Track],
                      live_counts: Dict[str, int], unique_counts: Dict[str, int]) -> np.ndarray:
    """Return a copy of `frame` with boxes, IDs and a count panel drawn on it."""

    annotated = frame.copy()

    for track_id, track in tracks.items():
        x1, y1, x2, y2 = [int(v) for v in track.box]
        color = _color_for(track.class_name)
        label = f"{track.class_name} #{track_id} ({track.confidence:.2f})"

        cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
        (text_w, text_h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        cv2.rectangle(annotated, (x1, max(0, y1 - text_h - 8)), (x1 + text_w + 4, y1), color, -1)
        cv2.putText(annotated, label, (x1 + 2, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (255, 255, 255), 1, cv2.LINE_AA)

    _draw_count_panel(annotated, unique_counts)
    return annotated


def _draw_count_panel(frame: np.ndarray, unique_counts: Dict[str, int]) -> None:
    """Semi-transparent panel in the top-left corner showing running unique counts."""

    panel_lines = ["Unique object count:"] + [
        f"  {name}: {count}" for name, count in sorted(unique_counts.items())
    ] or ["Unique object count: (none yet)"]

    line_height = 22
    panel_w = 260
    panel_h = line_height * len(panel_lines) + 10

    overlay = frame.copy()
    cv2.rectangle(overlay, (10, 10), (10 + panel_w, 10 + panel_h), (20, 20, 20), -1)
    cv2.addWeighted(overlay, 0.55, frame, 0.45, 0, dst=frame)

    for i, line in enumerate(panel_lines):
        y = 10 + line_height * (i + 1) - 6
        cv2.putText(frame, line, (18, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                    (255, 255, 255), 1, cv2.LINE_AA)


def save_json_report(path: str, summary: Dict[str, int], total_frames: int, fps: float) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    payload = {
        "total_unique_objects": sum(summary.values()),
        "counts_by_class": summary,
        "video_stats": {"total_frames_processed": total_frames, "source_fps": fps},
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)


def save_csv_report(path: str, summary: Dict[str, int]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["class_name", "unique_count"])
        for class_name, count in summary.items():
            writer.writerow([class_name, count])
