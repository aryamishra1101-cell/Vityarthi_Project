"""
detector.py
-----------
Functional Module 1: Detection

Thin wrapper around an Ultralytics YOLO model that turns a raw BGR
frame (as returned by OpenCV's VideoCapture) into a list of clean
Detection objects. Isolating this in its own module means the rest
of the pipeline (tracking, counting, drawing) never has to know
which YOLO version or backend is being used underneath -
swapping yolov8n.pt for yolov8m.pt, or a custom-trained .pt file,
requires no other code changes (Maintainability / Scalability - NFR).
"""

from dataclasses import dataclass
from typing import List, Optional

import numpy as np


@dataclass
class Detection:
    """A single detected object in one frame."""

    class_id: int
    class_name: str
    confidence: float
    box: tuple  # (x1, y1, x2, y2) in pixel coordinates

    @property
    def centroid(self):
        x1, y1, x2, y2 = self.box
        return int((x1 + x2) / 2), int((y1 + y2) / 2)


class YoloDetector:
    """Loads a YOLO model once and runs inference frame by frame."""

    def __init__(self, model_path: str, confidence_threshold: float = 0.4,
                 iou_threshold: float = 0.45, device: str = "cpu",
                 classes_of_interest: Optional[List[str]] = None):
        self.model_path = model_path
        self.confidence_threshold = confidence_threshold
        self.iou_threshold = iou_threshold
        self.device = device
        self.classes_of_interest = set(c.strip().lower() for c in (classes_of_interest or []))
        self._model = None  # lazy-loaded so unit tests can import this
        # module without needing the (large) model weights on disk.

    def load(self):
        """Load the underlying Ultralytics model (raises a clear error on failure)."""
        try:
            from ultralytics import YOLO
        except ImportError as exc:  # pragma: no cover - environment issue
            raise RuntimeError(
                "The 'ultralytics' package is required. Install it with "
                "'pip install -r requirements.txt'."
            ) from exc

        try:
            self._model = YOLO(self.model_path)
        except Exception as exc:  # noqa: BLE001 - surfaced to the caller with context
            raise RuntimeError(f"Could not load YOLO weights from '{self.model_path}': {exc}") from exc
        return self

    def detect(self, frame: np.ndarray) -> List[Detection]:
        """Run inference on a single frame and return a list of Detection objects."""
        if self._model is None:
            raise RuntimeError("Model not loaded - call .load() before .detect().")

        results = self._model.predict(
            source=frame,
            conf=self.confidence_threshold,
            iou=self.iou_threshold,
            device=self.device,
            verbose=False,
        )

        detections: List[Detection] = []
        if not results:
            return detections

        result = results[0]
        names = result.names  # {class_id: class_name}

        for box in result.boxes:
            class_id = int(box.cls[0])
            class_name = names.get(class_id, str(class_id))

            if self.classes_of_interest and class_name.lower() not in self.classes_of_interest:
                continue

            x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]
            confidence = float(box.conf[0])

            detections.append(
                Detection(
                    class_id=class_id,
                    class_name=class_name,
                    confidence=confidence,
                    box=(x1, y1, x2, y2),
                )
            )

        return detections
