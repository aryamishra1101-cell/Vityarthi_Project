"""Source package for the YOLO + OpenCV Unique-Object Video Counter project."""
