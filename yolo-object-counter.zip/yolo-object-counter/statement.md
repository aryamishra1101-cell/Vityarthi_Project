# Project Statement

## Problem Statement

Manually reviewing surveillance footage, traffic recordings, or retail
store videos to figure out *how many distinct objects* (people,
vehicles, animals, etc.) appeared over the course of a clip is slow
and error-prone. A simple frame-by-frame object detector is not
enough on its own: if the same person is visible for 200 frames, a
naive detector reports "person" 200 times, which is not a usable
answer to "how many people were in this video?"

This project builds a command-line tool that watches a video with a
YOLO object detector, uses a lightweight object tracker to recognise
when the same physical object is being seen across consecutive
frames, and reports **how many unique instances of each object class
appeared in the video**, together with an annotated copy of the video
that shows this running count live.

## Scope of the Project

- Input: any local video file supported by OpenCV (mp4, avi, mov) or
  a live webcam feed.
- Output:
  - An annotated video with bounding boxes, per-object track IDs, and
    a live "unique object count" panel.
  - A JSON and CSV summary report with the final unique count per
    object class.
- The project focuses on **general-purpose object counting** (using
  the 80 COCO classes that a pretrained YOLOv8 model already
  recognises) rather than one narrow use case, so it can be pointed
  at traffic footage, pedestrian footage, or any other everyday video
  without retraining.
- Out of scope: training a custom YOLO model from scratch, a graphical
  desktop/web UI, and real-time deployment on embedded hardware -
  all of these are listed as possible future enhancements in the
  project report.

## Target Users

- Students and instructors evaluating the project for the Computer
  Vision course.
- Anyone who wants a quick, reusable command-line utility for
  counting distinct objects in a video clip (e.g. estimating
  footfall in a shop entrance video, or vehicles passing a fixed
  camera).

## High-Level Features

1. **Detection module** - runs a pretrained YOLOv8 model on each
   video frame using OpenCV for video I/O.
2. **Tracking & unique-counting module** - links detections of the
   same object across frames (IoU-based association) and assigns a
   persistent ID, so each physical object is only counted once.
3. **Visualization & reporting module** - draws bounding boxes, IDs
   and a live count overlay on the output video, and exports the
   final tally as JSON/CSV.
