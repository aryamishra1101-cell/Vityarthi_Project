"""
Unit tests for src.counter.ObjectCounter

Run with:  python -m pytest tests/ -v
"""

import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.counter import ObjectCounter
from src.tracker import Track


def make_track(track_id, class_name="person"):
    return Track(track_id=track_id, class_name=class_name, box=(0, 0, 10, 10), confidence=0.9)


def test_new_track_increments_unique_count():
    counter = ObjectCounter()
    counter.update({1: make_track(1, "person")})
    assert counter.summary() == {"person": 1}


def test_same_track_id_across_frames_is_not_double_counted():
    counter = ObjectCounter()
    counter.update({1: make_track(1, "person")})
    counter.update({1: make_track(1, "person")})
    counter.update({1: make_track(1, "person")})
    assert counter.summary() == {"person": 1}


def test_multiple_distinct_ids_are_counted_separately():
    counter = ObjectCounter()
    counter.update({1: make_track(1, "car"), 2: make_track(2, "car")})
    assert counter.summary() == {"car": 2}


def test_live_counts_reflect_current_frame_only():
    counter = ObjectCounter()
    live = counter.update({1: make_track(1, "dog"), 2: make_track(2, "dog"), 3: make_track(3, "cat")})
    assert live == {"dog": 2, "cat": 1}


def test_total_unique_objects_sums_across_classes():
    counter = ObjectCounter()
    counter.update({1: make_track(1, "car"), 2: make_track(2, "person")})
    assert counter.total_unique_objects() == 2
