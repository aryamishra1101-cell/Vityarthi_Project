"""
counter.py
----------
Functional Module 2b: Unique-Occurrence Counting

Consumes the tracker's output and keeps two running tallies:

1. `unique_counts`   - how many DISTINCT objects of each class have
   ever appeared in the video (a track ID is only counted the first
   time it is seen).
2. `live_counts`     - how many objects of each class are visible in
   the CURRENT frame (useful for the on-screen overlay).

Keeping this separate from the tracker keeps each module small and
independently testable (Modularity / Maintainability - NFR).
"""

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, Set

from src.tracker import Track


@dataclass
class ObjectCounter:
    seen_track_ids: Set[int] = field(default_factory=set)
    unique_counts: Dict[str, int] = field(default_factory=lambda: defaultdict(int))

    def update(self, tracks: Dict[int, Track]) -> Dict[str, int]:
        """Register any brand-new track IDs and return this frame's live counts."""

        live_counts: Dict[str, int] = defaultdict(int)

        for track_id, track in tracks.items():
            live_counts[track.class_name] += 1
            if track_id not in self.seen_track_ids:
                self.seen_track_ids.add(track_id)
                self.unique_counts[track.class_name] += 1

        return live_counts

    def summary(self) -> Dict[str, int]:
        """Final unique-appearance count per class, for the end-of-run report."""
        return dict(sorted(self.unique_counts.items(), key=lambda kv: kv[0]))

    def total_unique_objects(self) -> int:
        return sum(self.unique_counts.values())
